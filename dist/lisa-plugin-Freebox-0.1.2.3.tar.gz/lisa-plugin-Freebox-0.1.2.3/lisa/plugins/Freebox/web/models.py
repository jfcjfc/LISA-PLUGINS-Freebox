from lisa.server.web.weblisa.settings import DBNAME

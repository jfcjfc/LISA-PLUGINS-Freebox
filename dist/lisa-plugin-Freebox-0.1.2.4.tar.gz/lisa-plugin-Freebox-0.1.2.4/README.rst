LISA Freebox plugin
========================
This module is used to have a conversation with Lisa

__author__ = 'jfcjfc'
from lisa.plugins.Freebox.web import *
from lisa.plugins.Freebox.modules import *
